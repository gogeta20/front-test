<?php

namespace Symfony\Config;

use Symfony\Component\Config\Loader\ParamConfigurator;
use Symfony\Component\Config\Definition\Exception\InvalidConfigurationException;

/**
 * This class is automatically generated to help in creating a config.
 */
class OpenaiConfig implements \Symfony\Component\Config\Builder\ConfigBuilderInterface
{
    private $apiKey;
    private $organization;
    private $_usedProperties = [];

    /**
     * @default '%env(OPENAI_API_KEY)%'
     * @param ParamConfigurator|mixed $value
     * @return $this
     */
    public function apiKey($value): static
    {
        $this->_usedProperties['apiKey'] = true;
        $this->apiKey = $value;

        return $this;
    }

    /**
     * @default '%env(default::OPENAI_ORGANIZATION)%'
     * @param ParamConfigurator|mixed $value
     * @return $this
     */
    public function organization($value): static
    {
        $this->_usedProperties['organization'] = true;
        $this->organization = $value;

        return $this;
    }

    public function getExtensionAlias(): string
    {
        return 'openai';
    }

    public function __construct(array $value = [])
    {
        if (array_key_exists('api_key', $value)) {
            $this->_usedProperties['apiKey'] = true;
            $this->apiKey = $value['api_key'];
            unset($value['api_key']);
        }

        if (array_key_exists('organization', $value)) {
            $this->_usedProperties['organization'] = true;
            $this->organization = $value['organization'];
            unset($value['organization']);
        }

        if ([] !== $value) {
            throw new InvalidConfigurationException(sprintf('The following keys are not supported by "%s": ', __CLASS__).implode(', ', array_keys($value)));
        }
    }

    public function toArray(): array
    {
        $output = [];
        if (isset($this->_usedProperties['apiKey'])) {
            $output['api_key'] = $this->apiKey;
        }
        if (isset($this->_usedProperties['organization'])) {
            $output['organization'] = $this->organization;
        }

        return $output;
    }

}
