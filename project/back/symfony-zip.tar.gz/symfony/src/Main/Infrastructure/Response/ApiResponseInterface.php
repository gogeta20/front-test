<?php

declare(strict_types=1);

namespace App\Main\Infrastructure\Response;

interface ApiResponseInterface
{
}
