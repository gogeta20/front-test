<?php

namespace App\Shared\Domain\Interfaces\Modelos;

interface ModelosMaestrasInterface
{
    function getAproveitamentos();
}
