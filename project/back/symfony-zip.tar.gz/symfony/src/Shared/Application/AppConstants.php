<?php

declare(strict_types=1);

namespace App\Shared\Application;

final class AppConstants
{
    const SUCCESS = 'success';
}
